* Holger Brunn <hbrunn@therp.nl>
* Stefan Rijnhart <stefan.rijnhart@opener.amsterdam>
* Ronald Portier <rportier@therp.nl>
* Andrea Stirpe <a.stirpe@onestein.nl>
* Maxence Groine <mgroine@fiefmanage.ch>
* Iryna Vyshnevska <i.vyshnevska@mobilunity.com>
* `Trobz <https://trobz.com>`_:

    * Son Ho <sonhd@trobz.com>
