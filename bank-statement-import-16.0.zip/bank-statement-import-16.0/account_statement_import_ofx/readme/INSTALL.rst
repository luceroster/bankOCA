This module requires the `ofxparse <https://pypi.org/project/ofxparse/>`_ python lib.
