* Odoo SA
* Alexis de Lattre <alexis.delattre@akretion.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Ronald Portier <rportier@therp.nl>
* Sylvain LE GAL <https://twitter.com/legalsylvain>
* Nicolas JEUDY <https://github.com/njeudy>
* Le Filament <https://github.com/lefilament>
