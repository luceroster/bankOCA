* Odoo S.A.
* Alexis de Lattre <alexis.delattre@akretion.com>
* Tecnativa - Pedro M. Baeza
